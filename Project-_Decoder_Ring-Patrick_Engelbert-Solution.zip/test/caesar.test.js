// Write your tests here!
const expect = require("chai").expect
const { caesar } = require("../src/caesar")

describe("caesar", () => {
  it("should exist", () => {
    expect().to.eql()
  })
  it("should return false If the shift value is not present, equal to 0, less than -25, or greater than 25", () => {
    let expected = false
    let actual = caesar("rnuats", 0)
    expect(actual).to.eql(expected)
  })
})